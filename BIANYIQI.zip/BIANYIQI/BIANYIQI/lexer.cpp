#include <iostream>
#include <fstream>
#include "lexer.h"
using namespace std;

int i=0,j=0,IDNUM=0,NUMNUM=0;

char c;//�������ݣ�
lexer::lexer(void)
{ 
	fileline=0;
	for(int q=0;q<14;q++)
		keywordstr[q].bianhao=q;
 keywordstr[0].KEYNAME="int";
 keywordstr[1].KEYNAME="void";
 keywordstr[2].KEYNAME="return";
 keywordstr[3].KEYNAME="virtual";
 keywordstr[4].KEYNAME="delete";
 keywordstr[5].KEYNAME="new";
 keywordstr[6].KEYNAME="protected";
 keywordstr[7].KEYNAME="public";
 keywordstr[8].KEYNAME="private";
 keywordstr[9].KEYNAME="class";
 keywordstr[10].KEYNAME="if";
 keywordstr[11].KEYNAME="else";
 keywordstr[12].KEYNAME="while";
 keywordstr[13].KEYNAME="this";
 BZtoken=0;
 pjtoken="";
}


lexer::~lexer(void)
{
}
void lexer:: Nextchar()
{
c=inputsave[i];
i++;
}
void lexer::panduanKey(string m)
{
	int index = 0;
	{ 
	for(;index<14;index++)
		if(keywordstr[index].KEYNAME == m)
			break;
	}
 switch (index)
		{

		case 0:
			token[BZtoken].ttype = INT;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 1:
			token[BZtoken].ttype = VOID;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
			 
		case 2:
			token[BZtoken].ttype = RETURN;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 3:
			token[BZtoken].ttype = VIRTUAL;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 4:
			token[BZtoken].ttype = DELETE;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 5:
			token[BZtoken].ttype = NEW;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 6:
			token[BZtoken].ttype = PROTECTED;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 7:
			token[BZtoken].ttype = PUBLIC;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 8:
			token[BZtoken].ttype = PRIVATE;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 9:
			token[BZtoken].ttype = CLASS;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 10:
			token[BZtoken].ttype = IF;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 11:
			token[BZtoken].ttype = ELSE;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 12:
			token[BZtoken].ttype = WHILE;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;
		case 13:
			token[BZtoken].ttype = THIS;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(" << index << ' ' << "keyword)";
			break;   
		 case 14:
	        IDsave[IDNUM++]=m;
			token[BZtoken].ttype = ID;
			token[BZtoken].word = m;
			token[BZtoken].line = fileline;
			cout << "(ID" << ' ' << IDNUM << ")";
			break; 
 }
}
bool lexer::scan()
{
	Nextchar();
	while(isspace(c))
	Nextchar();
    if(isalpha(c))
	{
    while (isalpha(c) || isdigit(c))
	{
			pjtoken+=c;	 
			Nextchar();
	} 
       i--;
	   c=NULL;
	panduanKey(pjtoken);
	}
	else if(isdigit(c))
	{
		while (isdigit(c))
		{
			pjtoken+=c;	 
			Nextchar();
		}
			  i--;
	        c=NULL;
			token[BZtoken].ttype=NUMBER;
			token[BZtoken].word =pjtoken;
			token[BZtoken].line=fileline;
			cout<<"(INT"<<' '<<pjtoken<<")";
			//constList[constNo++].value = strToken;
	}
		else if(c=='+')
	{
		token[BZtoken].ttype=PLUS;
		token[BZtoken].word="+";
		token[BZtoken].line=fileline;
		cout<<"($PLUS)";
	}
	else if(c=='-')
	{
		token[BZtoken].ttype=MINUS;
		token[BZtoken].word="-";
		token[BZtoken].line=fileline;
		cout<<"($MINUS)";
	}
	else if(c=='.')
	{
		token[BZtoken].ttype=DOT;
		token[BZtoken].word=".";
		token[BZtoken].line=fileline;
		cout<<"($DOT)";
	}
	else if(c==':')
	{
		token[BZtoken].ttype=COLON;
		token[BZtoken].word=":";
		token[BZtoken].line=fileline;
		cout<<"($COLON)";
	}
	else if(c=='*')
	{
		Nextchar();
		if(c=='/')
		{
			token[BZtoken].ttype=RCOMMENT;
			token[BZtoken].word="*/";
			token[BZtoken].line=fileline;
			cout<<"($RCOMMENT)";
		}
		else
		{
			i--;
			c=NULL;
			token[BZtoken].ttype=TIME;
			token[BZtoken].word="*";
			token[BZtoken].line=fileline;
			cout<<"($STAR)";
		}
	}
	else if(c=='/')
	{
		Nextchar();
		if(c=='*')
		{
			token[BZtoken].ttype=LCOMMENT;
			token[BZtoken].word="/*";
			token[BZtoken].line=fileline;
			cout<<"($LCOMMENT)";
		}
		else
		{
			i--;
			c=NULL;
			token[BZtoken].ttype=SLASH;
			token[BZtoken].word="/";
			token[BZtoken].line=fileline;
			cout<<"($SLASH)";
		}
	}
	else if(c=='=')
	{
		Nextchar();
		if(c=='=')
		{
			token[BZtoken].ttype=EQ;
			token[BZtoken].word="EQ";
			token[BZtoken].line=fileline;
			cout<<"($EQ)";
		}
		else
		{
			i--;
			c=NULL;
			token[BZtoken].ttype=ASSIGN;
			token[BZtoken].word="=";
			token[BZtoken].line=fileline;
			cout<<"($ASSIGN)";
		}
	}
	else if(c=='>')
	{
		Nextchar();
		if(c=='=')
		{
			token[BZtoken].ttype=GTEQ;
			token[BZtoken].word="GTEQ";
			token[BZtoken].line=fileline;
			cout<<"($GTEQ)";
		}
		else
		{
				i--;
			c=NULL;
		//	cout<<"($STAR)";
			token[BZtoken].ttype=GT;
			token[BZtoken].word="GT";
			token[BZtoken].line=fileline;
			cout<<"($GT)";
		}
	}
	else if(c=='<')
	{
		Nextchar();
		if(c=='=')
		{
			token[BZtoken].ttype=LTEQ;
			token[BZtoken].word="LTEQ";
			token[BZtoken].line=fileline;
			cout<<"($LTEQ)";
		}
		else
		{
				i--;
			c=NULL;
			token[BZtoken].ttype=LT;
			token[BZtoken].word="LT";
			token[BZtoken].line=fileline;
			cout<<"($LT)";
		}
	}
	else if(c==';')
	{
		token[BZtoken].ttype=SEMI;
		token[BZtoken].word="";
		token[BZtoken].line=fileline;
		cout<<"($SEMI)";
	}
	else if(c==',')
	{
		token[BZtoken].ttype=COMMA;
		token[BZtoken].word=",";
		token[BZtoken].line=fileline;
		cout<<"($COMMA)";
	}
	else if(c=='(')
	{
		token[BZtoken].ttype=LPAREN;
		token[BZtoken].word="(";
		token[BZtoken].line=fileline;
		cout<<"($LPAREN)";
	}
	else if(c==')')
	{
		token[BZtoken].ttype=RPAREN;
		token[BZtoken].word=")";
		token[BZtoken].line=fileline;
		cout<<"($RPAREN)";
	}
	else if(c=='{')
	{
		token[BZtoken].ttype=LBRACE;
		token[BZtoken].word="{";
		token[BZtoken].line=fileline;
		cout<<"($LBRACE)";
	}
	else if(c=='}')
	{
		token[BZtoken].ttype=RBRACE;
		token[BZtoken].word="}";
		token[BZtoken].line=fileline;
		cout<<"($RBRACE)";
	}
	else if (c== '[')
	{
		token[BZtoken].ttype = LSQUAR;
		token[BZtoken].word = "[";
		token[BZtoken].line = fileline;
		cout << "($RBRACE)";
	}
	else if (c == ']')
	{
		token[BZtoken].ttype = RSQUAR;
		token[BZtoken].word = "]";
		token[BZtoken].line = fileline;
		cout << "($RBRACE)";
	}
	else if (c == '!')
	{
		Nextchar();
		if (c == '=')
		{
			token[BZtoken].ttype = NEQ;
			token[BZtoken].word = "NEQ";
			token[BZtoken].line = fileline;
			cout << "($NEQ)";
		}
	}
			else if (c == 0)
	{
		i++;
		return 1;
		cout << "blank";
	}
		 
	else
	{
		cout<<"  ���ִ���  ";
	return false;
	}
	 pjtoken="";
	BZtoken++;
 	 return true;
}

int lexer::lexical()
{
	ifstream filename("C:\\a.txt");

	if(!filename)
	{
		cout<<"�ļ���ʧ��";
		return 0;
	}
	filename.seekg(0,ios::beg);
	string str;
	 while(!filename.eof())
	{
		i=0;
		memset(inputsave,0,100); 
		std::getline(filename,str);//����һ�д���
		str.copy(inputsave,str.length());
		fileline++;
		while(i<strlen(inputsave))
		{
			if(!scan())//scan()�˷����󷵻�0����ȷ����1
				return 0;
		}
		cout<<endl;
	}
	filename.close();
	return 1;
	 



}