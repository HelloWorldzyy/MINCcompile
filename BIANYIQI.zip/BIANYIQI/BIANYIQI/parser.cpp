﻿#include "parser.h"
#include<iostream>
using namespace std;

parser::parser(void)
{
}


parser::~parser(void)
{
}


Node* parser::Creat()
{
	Node*   newnode=new Node ;
	newnode->child1=NULL;
	newnode->child2=NULL;
	newnode->child3=NULL;

	newnode->declrname ="";
	newnode->returntyp =" ";
	newnode->vartype =" ";

	newnode->type=NONT;
	newnode ->isarray =0;
	return  newnode;

}

parser::parser(int totalnum,Token *tok)
{
	Total=totalnum-1;
	for(int i=0;i<totalnum;i++)
		token[i] =tok[i];
	tokpoint=0;
}
Node * parser::program()
{   
	Node * rootnode=Creat();
	Node * temp=rootnode;
	while(token[tokpoint].ttype ==VOID||token[tokpoint].ttype ==INT)
	{ Node* currentnode=Creat();
	if(token[tokpoint].ttype==VOID)
	{

		currentnode=fundecl();

	}
	else if(token[tokpoint].ttype==INT)
	{

		if(token[tokpoint+2].ttype==LPAREN)
		{ 
			currentnode=fundecl();
		}
		else
		{

			currentnode=vardecl();
		}

	}
	temp->child1 =currentnode;
	temp=currentnode;
	}

	if(tokpoint<Total)
	{
		cout<<"grammer error"<<endl;
	}else
	{
		cout<<"grammer succeed!"<<endl;
	}
	return rootnode;
}
//
Node* parser::vardecl(){


	Node* currentnode=Creat();
	if(token[tokpoint].ttype ==INT )
		tokpoint++;
	else
		cout<<"error  ";

	if(token[tokpoint].ttype ==ID )
		tokpoint++;
	else
		cout<<"error  ";
	currentnode->type = VarDecl;

	if(token[tokpoint].ttype==LSQUAR )
	{	
		currentnode->declrname =token[tokpoint-1].word;
		currentnode->vartype  ="int";
		currentnode->isarray =1;
		tokpoint++;
		if(token[tokpoint].ttype ==NUMBER   )
		{
			Node* currentnode1=Creat();
			currentnode1->declrname =token[tokpoint].word;
			currentnode1->type=ConstID;
			currentnode->child1=currentnode1;
		}
		else
			cout<<"error  ";

		tokpoint++;
		if(token[tokpoint].ttype ==RSQUAR  )
			tokpoint++;
		else
			cout<<"error  ";	

	}
	else
	{

		currentnode->declrname =token[tokpoint-1].word;
		currentnode->vartype  ="int";
			currentnode->isarray =0;

	}
	if(token[tokpoint].ttype==SEMI)
		tokpoint++;
	else
		cout<<"error  ";   


	return currentnode;

}
Node* parser::fundecl(){
	Node* currentnode=Creat();

	if(token[tokpoint].ttype ==INT ||token[tokpoint].ttype ==VOID)
		tokpoint++;
	else
		cout<<"error  ";

	if(token[tokpoint ].ttype ==ID)
		tokpoint++;
	else
		cout<<"error  ";

	currentnode->type=FunDecl;
	currentnode->returntyp= token[tokpoint-2].word;
	currentnode->declrname =token[tokpoint-1].word;

	if(token[tokpoint ].ttype ==LPAREN )
		tokpoint++;
	else
		cout<<"error  ";

	Node*  curnode2=Creat();
	curnode2=params();

	if(token[tokpoint ].ttype ==RPAREN )
		tokpoint++;
	else
		cout<<"error  ";
	if(token[tokpoint ].ttype ==LBRACE  )
		tokpoint++;
	else
		cout<<"error  ";
	Node*  curnode3=Creat();
	curnode3=statement();

	currentnode->child1=curnode2 ;
	currentnode ->child2=curnode3;


	return currentnode;
}
Node* parser::params()
{
	Node* firstnode= Creat();
	Node* temp=firstnode;

	while(token[tokpoint].ttype ==INT)
	{	
	Node* currentnode=Creat(); 	
	tokpoint+=2;
	currentnode->type = Para;
    currentnode->vartype  ="int";
	temp->child1=currentnode;
	temp=currentnode;
	if(token[tokpoint].ttype==LSQUAR )
	{	
		currentnode->declrname =token[tokpoint-1].word;
		currentnode->isarray =1;
		tokpoint++;
		 
		tokpoint++;
		if(token[tokpoint].ttype ==RSQUAR  )
			tokpoint++;
		else
			cout<<"error  ";	

	}
	else
	{

		currentnode->declrname =token[tokpoint-1].word;

	}
	if(token[tokpoint].ttype ==COMMA )
		tokpoint++;

	}


	return firstnode ;


}
Node* parser::statement()
{
	Node* firstnode=Creat();
	Node* temp=firstnode;
	while(token[tokpoint].ttype!=RBRACE )
	{
		 	
		while(token[tokpoint].ttype==INT)
		{
			Node* currentnode=Creat();
			tokpoint+=2;
			currentnode->type = VarDecl ;
			temp->child1=currentnode;
			temp=currentnode;
			if(token[tokpoint].ttype==LSQUAR )
			{	
				currentnode->declrname =token[tokpoint-1].word;
				currentnode->vartype  ="int";
				tokpoint++;
				if(token[tokpoint].ttype ==NUMBER   )
				{
					Node* currentnode1=Creat();
					currentnode1->declrname =token[tokpoint].word;
					currentnode1->type=ConstID;
					currentnode->child2 =currentnode1;
					 
				}
				else
					cout<<"error  ";

				tokpoint++;
				if(token[tokpoint].ttype ==RSQUAR  )
					tokpoint++;
				else
					cout<<"error  ";	

			}
			else
			{

				currentnode->declrname =token[tokpoint-1].word;
				currentnode->vartype  ="int";

			}

			if(token[tokpoint].ttype==SEMI)
				tokpoint++;
			else
				cout<<"error  ";   



		}	
		  while(token[tokpoint].ttype == WHILE ||token[tokpoint].ttype == RETURN||token[tokpoint].ttype == IF||token[tokpoint].ttype == ID||token[tokpoint].ttype == LBRACE  )
		{
			  Node* currentnode=Creat();
			switch(token[tokpoint].ttype)
			{

			case IF:
				currentnode=ifs ();
				break;
			case RETURN:
				currentnode= returns();
				break;
			case WHILE:
				currentnode= whiles();
				break;
			case LBRACE:
				currentnode= statement();
				break;
			default:
				currentnode= exps();
			}

			temp->child1 =currentnode;
			temp=currentnode;

		}


	}
	return firstnode ;
}
//return-stmt-> return [expression] ;
Node*  parser::returns()
{
	Node* currentnode=Creat();
	tokpoint++;
	currentnode->declrname =token[tokpoint-1].word ;
	if(token[tokpoint].ttype==ID||token[tokpoint].ttype==NUMBER||token[tokpoint].ttype==LPAREN)
	{
		Node* currentnode1=Creat ();
		currentnode1= exp();
		currentnode->child1=currentnode1;
	}
	currentnode->type =ReturnStm;
	if(token[tokpoint].ttype==SEMI)
		tokpoint++;
	else
		cout<<"error  ";   

	return currentnode;
}

//selection-stmt-> if ( expression ) statement [ else statement ]
Node*  parser::ifs()
{
	Node* currentnode=Creat ();

	currentnode->type =IfStm;
	currentnode->declrname =token[tokpoint].word ;
	tokpoint++;
	if(token[tokpoint].ttype==LPAREN)
		tokpoint++;
	Node* curnode1=Creat();

	curnode1= exp();

	if(token[tokpoint].ttype==RPAREN)
		tokpoint++;
	else
		cout<<"error";
	Node* curnode2=Creat();
	curnode2= statement();
	curnode2->type =IfStm;
	if(token[tokpoint].ttype==ELSE)
	{
		tokpoint++;
		Node* curnode3=Creat();
		curnode3= statement();
		currentnode->child3=curnode3;
		currentnode->type=IfElseStm;
	}
	currentnode->child2=curnode1;
	currentnode->child3=curnode2;
	return currentnode;
}

//iteration-stmt→ while( expression ) statement
Node*  parser::whiles()
{
	Node* currentnode=Creat();

	currentnode->type=WhileStm;
	currentnode->vartype=token[tokpoint].word; 
	tokpoint++;
	if(token[tokpoint].ttype==LPAREN)
		tokpoint++;
	else
		cout<<"error";
	Node*  curnode2=Creat();
	curnode2= exp();
	if(token[tokpoint].ttype==RPAREN)
		tokpoint++;
	else
		cout<<"error";
	Node*  curnode3=Creat();
	curnode3= statement();
	currentnode->child2=curnode2;
	currentnode->child3 =curnode3;
	return currentnode;
}

//expr_stmt   IDENT = expr; | IDENT [ expr ] = expr ; | ;  /*赋值语句*/
Node*  parser::exps()
{
	Node* curnode=Creat();
	if(token[tokpoint].ttype==ID||token[tokpoint].ttype==NUMBER)
	{
		curnode=exp();
	}
	if(token[tokpoint].ttype ==SEMI )
		tokpoint++;
	else 
		cout<<"error";
	return curnode;
}
//
Node* parser::exp()
{    
	Node* currentnode=Creat();

	if(token[tokpoint+1].ttype ==LSQUAR  )
	{
		Node* curnode1=Creat();
		curnode1->type =VarID;
		curnode1->declrname =token[tokpoint].word;
		curnode1->isarray=1;

		tokpoint+=4;
		if(token[tokpoint].ttype==AssignStm )
		{currentnode->type =AssignStm ;
		currentnode->declrname =token[tokpoint-4].word;
		Node* curnode2=Creat();
		curnode2= exp();
		currentnode->child2=curnode1;
		currentnode->child3=curnode2;	
		}
		else
			currentnode=Oexp();
	}
	else
	{
		if(token[tokpoint+1].ttype==ASSIGN)
		{
			Node* curnode1=Creat();
			curnode1->type =VarID;
			curnode1->declrname =token[tokpoint].word;
			curnode1->isarray=0;
			currentnode->type =AssignStm ;
			currentnode->declrname =token[tokpoint].word;
			tokpoint+=2;
			Node* curnode2=Creat();
			curnode2= exp();
			currentnode->child2=curnode1;
			currentnode->child3=curnode2;	
		}
		else
			currentnode=Oexp();	
	}
	return currentnode;
}
Node* parser::Oexp()
{
	Node* curnode1=Creat  ();
	Node* rootnode=Creat  ();
	curnode1= YSexp();
	if(token[tokpoint].ttype==LT||token[tokpoint].ttype==LTEQ||token[tokpoint].ttype==GT||
		token[tokpoint].ttype==GTEQ||token[tokpoint].ttype==EQ||token[tokpoint].ttype==NEQ)
	{
		Node* curnode=Creat ();
		curnode->declrname =token[tokpoint].word;
		switch(token[tokpoint ].ttype)
		{
		case LT:

			curnode->type=RLT;
			break;
		case LTEQ:

			curnode->type=RNGT;
			break;
		case GT:

			curnode->type=RGT;
			break;
		case GTEQ:

			curnode->type=RNLT;
			break;
		case EQ:

			curnode->type=REQ;
			break;
		case NEQ:

			curnode->type =RNEQ;
			break;
		}
		tokpoint++;
		Node* curnode2=Creat();

		curnode2=YSexp();
		curnode->child1 =curnode1;
		curnode->child2=curnode2;
		rootnode=curnode;
		return rootnode;
	}
	else return curnode1;
}
Node* parser::YSexp()
{
	Node* currentnode=Creat();
	Node* temp=Creat();
	currentnode=YS2exp();
	temp=currentnode  ;
	while(token[tokpoint].ttype ==PLUS||token[tokpoint].ttype ==MINUS)
	{
		Node* currentnode1=Creat();
		if(token[tokpoint].ttype ==PLUS)
		{
			currentnode1->type =ADD ;
			tokpoint++;
		}
		if(token[tokpoint].ttype ==MINUS)
		{
			currentnode1->type =SUB  ;
			tokpoint++;
		}
		Node* currentnode2=Creat();
		currentnode2=YS2exp();
		currentnode1->child1=temp;
		currentnode1->child2=currentnode2;
		temp=currentnode1;

	}
	return temp;//加法优先级低


}
Node* parser::YS2exp()
{
	Node* currentnode=Creat();
	Node* temp=Creat();
	currentnode=fac();
	temp=currentnode  ;
	while(token[tokpoint].ttype ==MUL ||token[tokpoint].ttype ==DIV)
	{
		Node* currentnode1=Creat();
		if(token[tokpoint].ttype ==TIME )
		{
			currentnode1->type = MUL;
			tokpoint++;
		}
		if(token[tokpoint].ttype ==SLASH )
		{
			currentnode1->type =DIV   ;
			tokpoint++;
		}
		Node* currentnode2=Creat();
		currentnode2=fac();
		currentnode1->child1=temp;
		currentnode1->child2=currentnode2;
		temp=currentnode1;

	}
	return temp;//



}


Node* parser::fac()
{
	Node* currentnode=Creat();

	if(token[tokpoint].ttype ==NUMBER)
	{
		currentnode->type =ConstID ;
		currentnode->declrname =token[tokpoint].word ;
		tokpoint++;
	}
	else if(token[tokpoint].ttype ==LPAREN ) 
	{
		tokpoint++;
		currentnode=exp();
		tokpoint++;
	}
	else if(token[tokpoint].ttype==ID&&token[tokpoint+1].ttype==LPAREN)
	{
		currentnode=call();
		currentnode->type=FunCall;
	}
	else{ 
		currentnode->type=VarID ;
		currentnode->declrname=token[tokpoint].word ;
		if(token[tokpoint].ttype==LSQUAR)
		{
			tokpoint++;
			Node* curnode1=Creat();
			if(token[tokpoint].ttype==NUMBER )
			{
				curnode1->type =ConstID ;
				curnode1->declrname =token[tokpoint].word ;
				tokpoint++;
			}
			else cout<<"error";

			if(token[tokpoint].ttype!=RSQUAR)

				cout<<"error";

			currentnode =curnode1;
			currentnode->isarray=1;
		}
		tokpoint++;
		currentnode->isarray=0;
	}
	return currentnode;

}
Node* parser::call()
{

	Node* curnode=Creat ();
	curnode->type=FunCall;
	curnode->declrname =token[tokpoint].word;
	tokpoint++;
	if(token[tokpoint].ttype==LPAREN)
	{
		tokpoint++;
		Node* curnode1=Creat ();	   
		curnode1= arg();
		tokpoint++;
		curnode->child1=curnode1;
	}
	return curnode;



}
Node* parser::arg()
{

	Node* curnode=Creat();
	Node* tempnode=curnode;
	if(token[tokpoint].ttype==ID||token[tokpoint].ttype==NUMBER)
	{
		tempnode->child1=exp();
		while(token[tokpoint].ttype==COMMA)
		{
			tokpoint++;
			Node* curnode1=Creat();
			curnode1=exp();
			while(tempnode->child1 !=0)
				tempnode=tempnode->child1;
			tempnode->child1=curnode1;
			tempnode=curnode1;
		}
	}
	curnode=curnode->child1;
	return curnode;
}



//先序遍历抽象语法树
void parser::Scan(Node * root)
{
	string op,arg1,arg2,result;
	if(root)
	{
		if(root->type==ADD||root->type==SUB
			||root->type==MUL||root->type==DIV)
		{
			if(root->child1!=0)
			{
                Scan(root->child1);
			}
			if(root->child2!=0)
			{
				Scan(root->child2);
			}
			if(root->child1->type!=VarID && root->child1->type!=ConstID)
			{
				if(root->child2->type!=VarID && root->child2->type!=ConstID)
				{
					 

					 
				}else
				{
					 
				}
			}else
			{
				arg1 = root->child1->declrname;
			}
			if((root->child2->type!=VarID) && (root->child2->type!=ConstID))
			{
				 
			}else
			{
				arg2 = root->child2->declrname;
			}
		 
			op = root->declrname;
			 
			if(root->child3!=0)
				Scan(root->child3);
		}
		if(root->type==REQ||root->type==RLT||
			root->type==RGT||root->type==RNEQ||root->type==RNGT||root->type== RNLT)
		{
			if(root->child1!=0)
			{
			Scan(root->child1);
			}
			if(root->child2!=0)
			{
				Scan(root->child2);
			}
			if(root->child3!=0)
				Scan(root->child3);
		}
		if(root->type==AssignStm)
		{
			if(root->child1!=0)
			{
			Scan(root->child1);
			}
			if(root->child2!=0)
			{
				Scan(root->child2);
			}
			if((root->child2->type!=VarID) && (root->child2->type!=ConstID))
			{
			 
			}else
			{
				arg2 = root->child2->declrname;
			}
			arg1 = root->child1->declrname;
			op = root->declrname;
			 
			if(root->child3!=0)
				Scan(root->child3);
		}
		if(root->type==WhileStm)
		{
			if(root->child1!=0)
			{
			Scan(root->child1);
			}
			op = 'J';
			op+=root->child1->declrname;
			if(root->child1->child1->type!=VarID && root->child1->child1->type!=ConstID)
			{
				if(root->child1->child2->type!=VarID && root->child1->child2->type!=ConstID)
				{
					 
				}else
				{
					 
				}
			}else
			{
				arg1 = root->child1->child1->declrname;
			}
			if(root->child1->child2->type!=VarID && root->child1->child2->type!=ConstID)
			{
				 
			}else
			{
				 
			}
			 
			if(root->child2!=0)
			{
				Scan(root->child2);
			}
			 
			if(root->child3!=0)
				Scan(root->child3);
		}
		if(root->type==IfStm)
		{
			if(root->child1!=0)
			{
			Scan(root->child1);
			}
			bool flag = false;
			op = 'J';
			op+=root->child1->declrname;
			if(root->child1->child1->type!=VarID && root->child1->child1->type!=ConstID)
			{
				if(root->child1->child2->type!=VarID && root->child1->child2->type!=ConstID)
				{
					 
				}else
				{
					 
				}
				flag  =true;
			}else
			{
				arg1 = root->child1->child1->declrname;
			}
			if(root->child1->child2->type!=VarID && root->child1->child2->type!=ConstID)
			{
				if (flag)
				{
					 
				}else
				{
					 
				}
			}else
			{
				arg2 =  root->child1->child2->declrname;
			}
			 
			//insertIndemediate("J","","","?");//需要回填，此为跳出循环
			if(root->child2!=0)
			{
				Scan(root->child2);
			}
			 
			if(root->child3!=0)
				Scan(root->child3);
		}
		if(root->type==IfElseStm)
		{
			if(root->child1!=0)
			{
				Scan(root->child1);
			}
			bool flag = false;
			op = 'J';
			op+=root->child1->declrname;
			if(root->child1->child1->type!=VarID && root->child1->child1->type!=ConstID)
			{
				
				flag  =true;
			}else
			{
				arg1 = root->child1->child1->declrname;
			}
			if(root->child1->child2->type!=VarID && root->child1->child2->type!=ConstID)
			{
				 
			}else
			{
				arg2 =  root->child1->child2->declrname;
			}
			 if(root->child2!=0)
			{
				Scan(root->child2);
			}
			 if(root->child2!=0)
			{
				Scan(root->child2);
			}
			 
			if(root->child3!=0)
				Scan(root->child3);
		}
		if(root->type==ConstID)
		{
			if(root->child1!=0)
			{
				Scan(root->child1);
			}
			if(root->child3!=0)
				Scan(root->child3);
		}
		if(root->type==VarID)
		{
			 
			if(root->child1!=0)
			{
				Scan(root->child1);
			}
			if(root->child3!=0)
				Scan(root->child3);
		}
		if(root->type==Para)
		{
			 
			if(root->child3!=0)
				Scan(root->child3);
		}

		if(root->type==ReturnStm)
		{
		 
			if(root->child1!=0)
			{
				Scan(root->child1);
			}
			op = "ret";
			result = root->child1->declrname;
	 
		}

	 

		if(root->type==VarDecl)
		{
			 
			if(root->child1!=0)
			{
				Scan(root->child1);
			}
	//		if(root->brother!=0)
		//		Scan(root->brother);
		}

		if(root->type==FunCall)
		{
			int i,dypara=0;//函数调用时的参数个数
		//	NodeList temproot=root;
		//	i=searchfun(root);
			if(root->child1!=0)
			{
				dypara++;
				root=root->child1;
		//		while(root->brother!=0)
			//	{
		//			root=root->brother;
			//		dypara++;
		//		}
			}
		//	funlist[funnum].size+=dypara;
		//	cout<<dypara<<i<<funlist[i].paraVarSize;
			 

			if(root->child1!=0)
			{
				Scan(root->child1);
			}
		//	NodeList temp = root->child1;
			int paraNum = 0;
			for(int i=0;i<10;i++)
			{
				int j;
				for(j=0;j<10;j++)
				{
				 
				}
				 
			}
	        int count = 0;

		 
			arg1 = root->declrname;
			//result = newTemp();
			//insertIndemediate("call",arg1,int2str(paraNum),result);

			if(root->child1)
			if(root->child2!=0)
				Scan(root->child2);
		}
	}
}
