#pragma once
#include<malloc.h>
#include"lexer.h"
enum NodeType
{
	FunDecl,VarDecl,Para,
	ADD, SUB, MUL, DIV, REQ, RLT, RGT, RNEQ, RNGT, RNLT,
	AssignStm,IfStm,IfElseStm,ElseStm,WhileStm,ReturnStm,
	FunCall, ConstID, VarID,NONT
};
struct Node{

	struct Node* child1;
	struct Node* child2;
	struct Node* child3;
	NodeType type;
	string returntyp;
	string declrname;
	bool isarray;
	string vartype;
} ;
struct info
{
	int line;
	char isActive;
};
class intermediateCodeTable
{
public:
	string op;
	string arg1;
	string arg2;
	string result;
	info left;
	info left_operator;
	info right_operator;
};
class parser
{
public:
	parser(void);
	~parser(void);
	parser(int totalnum, Token *tok);
	void Scan(Node * root);
	Node* program();//
	Node* vardecl();
	Node* fundecl();
	Node* Creat();
	Node* params();
	Node*  returns();
	Node*  ifs();
	Node*  whiles();
	Node*  exps();
	Node*  exp();
	Node* Oexp();
	Node* YSexp();
	Node* YS2exp();
	Node* statement();
	Node* fac();
	Node* call();
	Node* arg();
	Token token[200];
	int Total;
	int tokpoint;	
};

