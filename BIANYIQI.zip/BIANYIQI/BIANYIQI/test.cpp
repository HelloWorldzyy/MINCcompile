#include <iostream>
#include"lexer.h"
#include"parser.h"
using namespace std;
void SCAN(Node * root);

int main()
{
	 lexer a;
     a.lexical();
	 parser b(a.BZtoken,a.token);
	 Node *root=b.program();
		 SCAN(root);//b.Scan(root);
	 system("pause");
	 return 0;
}


void SCAN(Node * root)
{
	
if(root!=NULL)
{
	cout<<root->declrname <<"     "<<root->type<<"   "<<root->vartype <<"  "<<root->returntyp     <<endl ;

}
}